/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.beaconhillcott.moodlerest;

/**
 * Class to relate a user to a role within a particular context. Problem here as of 2011-02-13 there is no way of obtaining the contextid or roleid programatically through the standard web services interface.
 * @see MoodleRestEnrol
 * @author Bill Antonia
 */
public class MoodleEnrolUser {

    private long roleid=-1;
    private long userid=-1;
    private long contextid=-1;

    /**
     * Constructor for bean requirements.
     */
    public MoodleEnrolUser() {}

    /**
     * Constructor to create a MoodleEnrolUser object with known roleid, userid and contextid.
     * @param roleid long
     * @param userid long
     * @param contextid long
     */
    public MoodleEnrolUser(long roleid, long userid, long contextid) {
        this.roleid=roleid;
        this.userid=userid;
        this.contextid=contextid;
    }

    /**
     * Method to set the roleid attribute of a MoodleEnrolUser object. The roleid currently cannot be retrieved through the standard web services interfaces.
     * @param roleid long
     */
    public void setRoleId(long roleid) {
        this.roleid=roleid;
    }

    /**
     * Method to set the userid attribute of a MoodleEnrolUser object.
     * @param userid long
     */
    public void setUserId(long userid) {
        this.userid=userid;
    }

    /**
     * Method to set the contextid attribute of a MoodleEnrolUser object. The contextid currently cannot be retrieved through the standard web services interfaces.
     * @param contextid long
     */
    public void setContextId(long contextid) {
        this.contextid=contextid;
    }

    /**
     * Method to get the roleid attribute of a MoodleEnrolUser object.
     * @return roleid long
     */
    public long getRoleId() {
        return roleid;
    }

    /**
     * Method to get the userid attribute of a MoodleEnrolUser object.
     * @return userid long
     */
    public long getUserId() {
        return userid;
    }

    /**
     * Method to get the contextid attribute of a MoodleEnrolUser object.
     * @return contextid long
     */
    public long getContextId() {
        return contextid;
    }
}
