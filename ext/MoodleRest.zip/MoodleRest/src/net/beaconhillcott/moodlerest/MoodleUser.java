/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.beaconhillcott.moodlerest;

/**
 * Class to hold the state of a MoodleUser object. Used when creating, updating or fetching user information in Moodle.
 * @see MoodleRestUser
 * @author Bill Antonia
 */
public class MoodleUser {

    public static final boolean EMAIL_FORMAT_NONE = false;
    public static final boolean EMAIL_FORMAT_HTML = true;
    
    private long id=-1;
    private String username=null;
    private String password=null;
    private String firstname=null;
    private String lastname=null;
    private String email=null;
    private String auth=null;
    private String idnumber=null;
    private String lang=null;
    private String theme=null;
    private String timezone=null;
    private boolean mailformat=EMAIL_FORMAT_HTML;
    private String description=null;
    private String city=null;
    private String country=null;

    /**
     * Constructor for bean requirements
     */
    public MoodleUser() {}

    /**
     * Constructor which also sets the MoodleUser id attribute. Use this constructor when fetching user information from Moodle. Once the users information has been populated from Moodle it can then be used as a template to update the same users information.
     * @param id long
     */
    public MoodleUser(long id) {
        this.id=id;
    }

    /**
     * Constructor to create a new MoodleUser object with the minimum settings required which to create a new user in Moodle. Note there are other required attributes which are set to default values for the creation of a new user in Moodle.
     * @param username String
     * @param password String Note this will be passed as clear text, no encryption is carried out in this layer.
     * @param firstname String
     * @param lastname String
     * @param email String
     */
    public MoodleUser(String username, String password, String firstname, String lastname, String email) {
        this.username=username;
        this.password=password;
        this.firstname=firstname;
        this.lastname=lastname;
        this.email=email;
    }

    /**
     * Method to update the named MoodleUser attribute with the value of content. Note type conversion takes place from Strings.
     * @param nodeName String The attribute name to update.
     * @param content String The attributes value to set.
     */
    public void setMoodleUserField(String nodeName,String content) {
        if (nodeName.equals("id")) setId(Integer.parseInt(content));
        if (nodeName.equals("username")) setUsername(content);
        if (nodeName.equals("firstname")) setFirstname(content);
        if (nodeName.equals("lastname")) setLastname(content);
        if (nodeName.equals("email")) setEmail(content);
        if (nodeName.equals("auth")) setAuth(content);
        if (nodeName.equals("idnumber") && !content.equals("")) setIdNumber(content);
        if (nodeName.equals("lang") && !content.equals("")) setLang(content);
        if (nodeName.equals("theme") && !content.equals("")) setTheme(content);
        if (nodeName.equals("timezone") && !content.equals("")) setTimezone(content);
        if (nodeName.equals("mailformat") && !content.equals("")) setMailFormat(Integer.parseInt(content)==0?EMAIL_FORMAT_NONE:EMAIL_FORMAT_HTML);
        if (nodeName.equals("description") && !content.equals("")) setDescription(content);
        if (nodeName.equals("city") && !content.equals("")) setCity(content);
        if (nodeName.equals("country") && !content.equals("")) setCountry(content);
    }

    /**
     * Method to get the id attribute of a MoodleUser object. When a user is created in Moodle this attribute will be updated.
     * @return id long
     */
    public long getId() {
        return id;
    }

    /**
     * Method to get the username attribute of a MoodleUser object.
     * @return username String
     */
    public String getUsername() {
        return username;
    }

    /**
     * Method to get the password attribute of a MoodleUser object. Note this will only contain the password if it has been set during user creation, it will be null if fetching user information from Moodle.
     * @return password String
     */
    public String getPassword() {
        return password;
    }

    /**
     * Method to get the firstname attribute of a MoodleUser object.
     * @return firstname String
     */
    public String getFirstname() {
        return firstname;
    }

    /**
     * Method to get the lastname attribute of a MoodleUser object.
     * @return lastname String
     */
    public String getLastname() {
        return lastname;
    }

    /**
     * Method to get the email attribute of a MoodleUser object
     * @return email String
     */
    public String getEmail() {
        return email;
    }

    /**
     * Method to get the auth attribute of a MoodleUser object. This will return the name of the authorisation process assigned to the user i.e. manual, ldap, database etc.
     * @return auth String
     */
    public String getAuth() {
        return auth;
    }

    /**
     * Method to get the idnumber attribute of a MoodleUser object. Note this attribute may be alphanumeric.
     * @return idnumber String
     */
    public String getIdNumber() {
        return idnumber;
    }

    /**
     * Method to get the lang attribute of a MoodelCourse object.
     * @return lang String
     */
    public String getLang() {
        return lang;
    }

    /**
     * Method to get the theme attribute of a MoodelCourse object.
     * @return theme String
     */
    public String getTheme() {
        return theme;
    }

    /**
     * Method to get the timezone attribute of a MoodleUser object.
     * @return timezone String
     */
    public String getTimezone() {
        return timezone;
    }

    /**
     * Method to get the mailformat attribute of a MoodleUser object.
     * @return mailformat boolean
     */
    public boolean getMailFormat() {
        return mailformat;
    }

    /**
     * Method to test the mailformat attribute of a MoodleUser object.
     * @return mailformat boolean. True HTML format, False Text format.
     */
    public boolean isEmailHTMLFormat() {
        return mailformat;
    }

    /**
     * Method to get the description attribute of a MoodleUser object.
     * @return description String
     */
    public String getDescription() {
        return description;
    }

    /**
     * Method to get the city attribute of a MoodleCourse object.
     * @return city String
     */
    public String getCity() {
        return city;
    }

    /**
     * Method to get the country attribute of a MoodleUser object.
     * @return country String
     */
    public String getCountry() {
        return country;
    }

    /**
     * Method to set the id attribute of a MoodleUser object.
     * @param id long
     */
    public void setId(long id) {
        this.id=id;
    }

    /**
     * Method to set the username attribute of a MoodleUser object.
     * @param username String
     */
    public void setUsername(String username) {
        this.username=username;
    }

    /**
     * Method to set the password attribute of a MoodleCourse object.
     * @param password String
     */
    public void setPassword(String password) {
        this.password=password;
    }

    /**
     * Method to set the firstname attribute of a MoodleCourse object.
     * @param firstname String
     */
    public void setFirstname(String firstname) {
        this.firstname=firstname;
    }

    /**
     * Method to set the lastname attribute of a MoodleCourse object.
     * @param lastname String
     */
    public void setLastname(String lastname) {
        this.lastname=lastname;
    }

    /**
     * Method to set the email attribute of a MoodleCourse object.
     * @param email String
     */
    public void setEmail(String email) {
        this.email=email;
    }

    /**
     * Method to set the auth attribute of a MoodleCourse object.
     * @param auth String
     */
    public void setAuth(String auth) {
        this.auth=auth;
    }

    /**
     * Method to set the idnumber attribute of a MoodleCourse object. This can be an alphanumeric string.
     * @param idnumber String
     */
    public void setIdNumber(String idnumber) {
        this.idnumber=idnumber;
    }

    /**
     * Method to set the lang attribute of a MoodleCourse object.
     * @param lang String
     */
    public void setLang(String lang) {
        this.lang=lang;
    }

    /**
     * Method to set the theme attribute of a MoodleCourse object.
     * @param theme String
     */
    public void setTheme(String theme) {
        this.theme=theme;
    }

    /**
     * Method to set the timezone attribute of a MoodleCourse object.
     * @param timezone String
     */
    public void setTimezone(String timezone) {
        this.timezone=timezone;
    }

    /**
     * Method to set the mailformat attribute of a MoodleCourse object. True HTML format, False Text format.
     * @param mailformat boolean
     */
    public void setMailFormat(boolean mailformat) {
        this.mailformat=mailformat;
    }

    /**
     * Method to set the description attribute of a MoodleCourse object.
     * @param description String
     */
    public void setDescription(String description) {
        this.description=description;
    }

    /**
     * Method to set the city attribute of a MoodleCourse object.
     * @param city String
     */
    public void setCity(String city) {
        this.city=city;
    }

    /**
     * Method to set the country attribute of a MoodleCourse object.
     * @param country String
     */
    public void setCountry(String country) {
        this.country=country;
    }

}
