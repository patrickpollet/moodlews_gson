/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.beaconhillcott.moodlerest;

/**
 *
 * @author root
 */
public class MoodleRestException extends Exception {

    MoodleRestException() {}

    MoodleRestException(String msg) {
        super(msg);
    }
}
