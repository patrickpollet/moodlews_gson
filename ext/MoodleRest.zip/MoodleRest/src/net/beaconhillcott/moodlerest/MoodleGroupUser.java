/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.beaconhillcott.moodlerest;

/**
 * Class to store the details of the connection between a user and a Moodle group.
 * @see MoodleRestGroup
 * @author Bill Antonia
 */
public class MoodleGroupUser {

    private long groupid=-1;
    private long userid=-1;

    /**
     * Constructor for bean requirements
     */
    public MoodleGroupUser() {}

    /**
     * Constructor to create a MoodleGroupUser object given the group and user ids.
     * @param groupid long
     * @param userid long
     */
    public MoodleGroupUser(long groupid, long userid) {
        this.groupid=groupid;
        this.userid=userid;
    }

    /**
     * Method to set the groupid attribute of a MoodleGroupUser object.
     * @param groupid long
     */
    public void setGroupId(long groupid) {
        this.groupid=groupid;
    }

    /**
     * Method to set the userid attribute of a MoodleGroupUser object.
     * @param userid long
     */
    public void setUserId(long userid) {
        this.userid=userid;
    }

    /**
     * Method to get the groupid attribute of a MoodleGroupUser object.
     * @return groupid long
     */
    public long getGroupId() {
        return groupid;
    }

    /**
     * Method to get the userid attribute of a MoodleGroupUser object.
     * @return userid long
     */
    public long getUserId() {
        return userid;
    }
}
