/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.beaconhillcott.moodlerest;

/**
 *
 * @author root
 */
public class MoodleRestGroupException extends MoodleRestException {

    MoodleRestGroupException() {}

    MoodleRestGroupException(String msg) {
        super(msg);
    }

}
