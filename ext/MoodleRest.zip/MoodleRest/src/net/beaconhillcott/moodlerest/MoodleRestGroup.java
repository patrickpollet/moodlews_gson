/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.beaconhillcott.moodlerest;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Hashtable;
import java.util.Vector;
import org.w3c.dom.NodeList;

/**
 * Class containing the static routines to manipulate Moodle groups and users within course groups.
 * @see MoodleGroup
 * @see MoodleGroupUser
 * @author Bill Antonia
 */
public class MoodleRestGroup {

    private static final int BUFFER_MAX=4000;

    /**
     * Method to create a new group in a Moodle course
     * @param group MoodleGroup
     * @return group MoodleGroup object
     * @throws MoodleRestGroupException
     * @throws UnsupportedEncodingException
     */
    public static MoodleGroup createGroup(MoodleGroup group) throws MoodleRestGroupException, UnsupportedEncodingException {
        MoodleGroup[] a=new MoodleGroup[1];
        a[0]=group;
        MoodleGroup[] gps=createGroups(a);
        return gps[0];
    }

    /**
     * Method to create new groups in Moodle courses. Groups to be created do not necessarily need to be within the same course.
     * @param group MoodleGroup[]
     * @return group MoodleGroup[] Updated array of MoodleGroup objects. Group ids created by Moodle stored in the id attribute of each object.
     * @throws MoodleRestGroupException
     * @throws UnsupportedEncodingException
     */
    public static MoodleGroup[] createGroups(MoodleGroup[] group) throws MoodleRestGroupException, UnsupportedEncodingException {
        Hashtable hash=new Hashtable();
        boolean processed=false;
        StringBuilder data=new StringBuilder();
        if (MoodleRestWebService.getAuth()==null)
            throw new MoodleRestGroupException();
        else
            data.append(MoodleRestWebService.getAuth());
        data.append("&").append(URLEncoder.encode("wsfunction", "UTF-8")).append("=").append(URLEncoder.encode("moodle_group_create_groups", "UTF-8"));
        for (int i=0;i<group.length;i++) {
            if (group[i]==null) throw new MoodleRestGroupException();
            if (group[i].getCourseId()<0) throw new MoodleRestGroupException(); else data.append("&").append(URLEncoder.encode("groups["+i+"][courseid]", "UTF-8")).append("=").append(URLEncoder.encode(""+group[i].getCourseId(), "UTF-8"));
            if (group[i].getName()==null || group[i].getName().equals("")) throw new MoodleRestGroupException(); else data.append("&").append(URLEncoder.encode("groups["+i+"][name]", "UTF-8")).append("=").append(URLEncoder.encode(""+group[i].getName(), "UTF-8"));
            if (group[i].getDescription()==null) throw new MoodleRestGroupException(); else data.append("&").append(URLEncoder.encode("groups["+i+"][description]", "UTF-8")).append("=").append(URLEncoder.encode(""+group[i].getDescription(), "UTF-8"));
            if (group[i].getEnrolmentKey()==null) throw new MoodleRestGroupException(); else data.append("&").append(URLEncoder.encode("groups["+i+"][enrolmentkey]", "UTF-8")).append("=").append(URLEncoder.encode(""+group[i].getEnrolmentKey(), "UTF-8"));
            if (data.length()>=BUFFER_MAX) {
                processed=true;
                data.trimToSize();
                NodeList elements=MoodleRestWebService.call(data.toString());
                for (int j=0;j<elements.getLength();j+=5) {
                    hash.put(elements.item(j+2).getTextContent(), elements.item(j).getTextContent());
                }
                data=new StringBuilder();
                data.append(MoodleRestWebService.getAuth());
                data.append("&").append(URLEncoder.encode("wsfunction", "UTF-8")).append("=").append(URLEncoder.encode("moodle_group_create_groups", "UTF-8"));
            } else
                processed=false;
        }
        if (!processed) {
            data.trimToSize();
            NodeList elements=MoodleRestWebService.call(data.toString());
            for (int j=0;j<elements.getLength();j+=5) {
                hash.put(elements.item(j+1).getTextContent(), elements.item(j).getTextContent());
            }
        }
        for (int i=0;i<group.length;i++) {
            if (hash.containsKey(group[i].getName()))
                group[i].setId(Long.parseLong((String)(hash.get(group[i].getName()))));
            else
                group[i]=null;
        }
        return group;
    }

    /**
     * Method to retrieve the information about a Moodle group from its id.
     * @param groupid long
     * @return group MoodleGroup
     * @throws MoodleRestGroupException
     * @throws UnsupportedEncodingException
     */
    public static MoodleGroup getGroupById(long groupid) throws MoodleRestGroupException, UnsupportedEncodingException {
        long[] a=new long[1];
        a[0]=groupid;
        MoodleGroup[] gps=getGroupsById(a);
        return gps[0];
    }

    /**
     * Method to fetch the details of a number of Moodle groups from their ids.
     * @param groupids long[]
     * @return group MoodleGroup[]
     * @throws MoodleRestGroupException
     * @throws UnsupportedEncodingException
     */
    public static MoodleGroup[] getGroupsById(long[] groupids) throws MoodleRestGroupException, UnsupportedEncodingException {
        Vector v=new Vector();
        MoodleGroup group=null;
        boolean processed=false;
        StringBuilder data=new StringBuilder();
        if (MoodleRestWebService.getAuth()==null)
            throw new MoodleRestGroupException();
        else
            data.append(MoodleRestWebService.getAuth());
        data.append("&").append(URLEncoder.encode("wsfunction", "UTF-8")).append("=").append(URLEncoder.encode("moodle_group_get_groups", "UTF-8"));
        for (int i=0;i<groupids.length;i++) {
            if (groupids[i]<1) throw new MoodleRestGroupException(); data.append("&").append(URLEncoder.encode("groupids["+i+"]", "UTF-8")).append("=").append(groupids[i]);
            if (data.length()>=BUFFER_MAX) {
                processed=true;
                data.trimToSize();
                NodeList elements=MoodleRestWebService.call(data.toString());
                group=null;
                for (int j=0;j<elements.getLength();j++) {
                    String content=elements.item(j).getTextContent();
                    String nodeName=elements.item(j).getParentNode().getAttributes().getNamedItem("name").getNodeValue();
                    if (nodeName.equals("id")) {
                        if (group==null)
                            group=new MoodleGroup(Long.parseLong(content));
                        else {
                            v.add(group);
                            group=new MoodleGroup(Long.parseLong(content));
                        }
                    }
                    group.setMoodleGroupField(nodeName, content);
                }
                data=new StringBuilder();
                data.append(MoodleRestWebService.getAuth());
                data.append("&").append(URLEncoder.encode("wsfunction", "UTF-8")).append("=").append(URLEncoder.encode("moodle_group_get_groups", "UTF-8"));
            } else
                processed=false;
        }
        if (!processed) {
            data.trimToSize();
            NodeList elements=MoodleRestWebService.call(data.toString());
            group=null;
            for (int j=0;j<elements.getLength();j++) {
                String content=elements.item(j).getTextContent();
                String nodeName=elements.item(j).getParentNode().getAttributes().getNamedItem("name").getNodeValue();
                if (nodeName.equals("id")) {
                    if (group==null)
                        group=new MoodleGroup(Long.parseLong(content));
                    else {
                        v.add(group);
                        group=new MoodleGroup(Long.parseLong(content));
                    }
                }
                group.setMoodleGroupField(nodeName, content);
            }
        }
        if (group!=null)
            v.add(group);
        MoodleGroup[] groups=new MoodleGroup[v.size()];
        for (int i=0;i<v.size();i++) {
            groups[i]=(MoodleGroup)v.get(i);
        }
        v.removeAllElements();
        return groups;
    }

    /**
     * Method to return the details of groups within a Moodle course from the course id.
     * @param id long
     * @return groups MoodleGroup[]
     * @throws MoodleRestGroupException
     * @throws UnsupportedEncodingException
     */
    public static MoodleGroup[] getGroupsFromCourseId(long id) throws MoodleRestGroupException, UnsupportedEncodingException {
        Vector v=new Vector();
        MoodleGroup group=null;
        StringBuilder data=new StringBuilder();
        if (MoodleRestWebService.getAuth()==null)
            throw new MoodleRestGroupException();
        else
            data.append(MoodleRestWebService.getAuth());
        data.append("&").append(URLEncoder.encode("wsfunction", "UTF-8")).append("=").append(URLEncoder.encode("moodle_group_get_course_groups", "UTF-8"));
        if (id<1) throw new MoodleRestGroupException(); else  data.append("&").append(URLEncoder.encode("courseid", "UTF-8")).append("=").append(id);
        NodeList elements=MoodleRestWebService.call(data.toString());
        for (int j=0;j<elements.getLength();j++) {
            String content=elements.item(j).getTextContent();
            String nodeName=elements.item(j).getParentNode().getAttributes().getNamedItem("name").getNodeValue();
            if (nodeName.equals("id")) {
                if (group==null)
                    group=new MoodleGroup(Long.parseLong(content));
                else  {
                    v.add(group);
                    group=new MoodleGroup(Long.parseLong(content));
                }
            }
            group.setMoodleGroupField(nodeName, content);
        }
        if (group!=null)
            v.add(group);
        MoodleGroup[] groups=new MoodleGroup[v.size()];
        for (int i=0;i<v.size();i++) {
            groups[i]=(MoodleGroup)v.get(i);
        }
        v.removeAllElements();
        return groups;
    }

    /**
     * Method to delete a Moodle group given its id.
     * @param groupid long
     * @throws MoodleRestGroupException
     * @throws UnsupportedEncodingException
     */
    public static void deleteGroupById(long groupid) throws MoodleRestGroupException, UnsupportedEncodingException {
        long[] a=new long[1];
        a[0]=groupid;
        deleteGroupsById(a);
    }

    /**
     * Method to delete groups from Moodle given the ids of the groups.
     * @param groupids long[]
     * @throws MoodleRestGroupException
     * @throws UnsupportedEncodingException
     */
    public static void deleteGroupsById(long[] groupids) throws MoodleRestGroupException, UnsupportedEncodingException {
        boolean processed=false;
        StringBuilder data=new StringBuilder();
        if (MoodleRestWebService.getAuth()==null)
            throw new MoodleRestGroupException();
        else
            data.append(MoodleRestWebService.getAuth());
        data.append("&").append(URLEncoder.encode("wsfunction", "UTF-8")).append("=").append(URLEncoder.encode("moodle_group_delete_groups", "UTF-8"));
        for (int i=0;i<groupids.length;i++) {
            if (groupids[i]<1) throw new MoodleRestGroupException(); data.append("&").append(URLEncoder.encode("groupids["+i+"]", "UTF-8")).append("=").append(groupids[i]);
            if (data.length()>=BUFFER_MAX) {
                processed=true;
                data.trimToSize();
                MoodleRestWebService.call(data.toString());
                data=new StringBuilder();
                data.append(MoodleRestWebService.getAuth());
                data.append("&").append(URLEncoder.encode("wsfunction", "UTF-8")).append("=").append(URLEncoder.encode("moodle_group_delete_groups", "UTF-8"));
            } else
                processed=false;
        }
        if (!processed) {
            data.trimToSize();
            MoodleRestWebService.call(data.toString());
        }
    }

    /**
     * Method to retrieve details of the memberships of a Moodle group.
     * @param groupid long
     * @return groupUsers MoodleGroupUser[]
     * @throws MoodleRestGroupException
     * @throws UnsupportedEncodingException
     */
    public static MoodleGroupUser[] getMembersFromGroupId(long groupid) throws MoodleRestGroupException, UnsupportedEncodingException {
        long[] a=new long[1];
        a[0]=groupid;
        return getMembersFromGroupIds(a);
    }

    /**
     * Method to retrieve details of the memberships of a number of Moodle groups.
     * @param groupids long[]
     * @return groupUsers MoodleGroupUser[]
     * @throws MoodleRestGroupException
     * @throws UnsupportedEncodingException
     */
    public static MoodleGroupUser[] getMembersFromGroupIds(long[] groupids) throws MoodleRestGroupException, UnsupportedEncodingException {
        Vector v=new Vector();
        MoodleGroupUser user=null;
        boolean processed=false;
        StringBuilder data=new StringBuilder();
        if (MoodleRestWebService.getAuth()==null)
            throw new MoodleRestGroupException();
        else
            data.append(MoodleRestWebService.getAuth());
        data.append("&").append(URLEncoder.encode("wsfunction", "UTF-8")).append("=").append(URLEncoder.encode("moodle_group_get_groupmembers", "UTF-8"));
        for (int i=0;i<groupids.length;i++) {
            if (groupids[i]<1) throw new MoodleRestGroupException(); data.append("&").append(URLEncoder.encode("groupids["+i+"]", "UTF-8")).append("=").append(groupids[i]);
            if (data.length()>=BUFFER_MAX) {
                processed=true;
                data.trimToSize();
                NodeList elements=MoodleRestWebService.call(data.toString());
                user=null;
                for (int j=0;j<elements.getLength();j+=2) {
                    String content1=elements.item(j).getTextContent();
                    String content2=elements.item(j+1).getTextContent();
                    user=new MoodleGroupUser(Long.parseLong(content1),Long.parseLong(content2));
                    v.add(user);
                }
                data=new StringBuilder();
                data.append(MoodleRestWebService.getAuth());
                data.append("&").append(URLEncoder.encode("wsfunction", "UTF-8")).append("=").append(URLEncoder.encode("moodle_group_get_groupmembers", "UTF-8"));
            } else
                processed=false;
        }
        if (!processed) {
            data.trimToSize();
            NodeList elements=MoodleRestWebService.call(data.toString());
            user=null;
            if (elements.getLength()!=1) {
                for (int j=0;j<elements.getLength();j+=2) {
                    String content1=elements.item(j).getTextContent();
                    String content2=elements.item(j+1).getTextContent();
                    user=new MoodleGroupUser(Long.parseLong(content1),Long.parseLong(content2));
                }
            }
        }
        if (user!=null)
            v.add(user);
        MoodleGroupUser[] users=new MoodleGroupUser[v.size()];
        for (int i=0;i<v.size();i++) {
            users[i]=(MoodleGroupUser)v.get(i);
        }
        v.removeAllElements();
        return users;
    }

    /**
     * Method to add a users membership to a Moodle group.
     * @param user MoodleGroupUser
     * @throws MoodleRestGroupException
     * @throws UnsupportedEncodingException
     */
    public static void addMemberToGroup(MoodleGroupUser user) throws MoodleRestGroupException, UnsupportedEncodingException {
        MoodleGroupUser[] users=new MoodleGroupUser[1];
        users[0]=user;
        addMembersToGroups(users);
    }

    /**
     * Method to add a number of users memberships to a number of Moodle groups.
     * @param users MoodleGroupUser[]
     * @throws MoodleRestGroupException
     * @throws UnsupportedEncodingException
     */
    public static void addMembersToGroups(MoodleGroupUser[] users) throws MoodleRestGroupException, UnsupportedEncodingException {
        Hashtable hash=new Hashtable();
        boolean processed=false;
        StringBuilder data=new StringBuilder();
        if (MoodleRestWebService.getAuth()==null)
            throw new MoodleRestGroupException();
        else
            data.append(MoodleRestWebService.getAuth());
        data.append("&").append(URLEncoder.encode("wsfunction", "UTF-8")).append("=").append(URLEncoder.encode("moodle_group_add_groupmembers", "UTF-8"));
        for (int i=0;i<users.length;i++) {
            if (users[i]==null) throw new MoodleRestGroupException();
            if (users[i].getGroupId()<1) throw new MoodleRestGroupException(); else data.append("&").append(URLEncoder.encode("members["+i+"][groupid]", "UTF-8")).append("=").append(URLEncoder.encode(""+users[i].getGroupId(), "UTF-8"));
            if (users[i].getUserId()<1) throw new MoodleRestGroupException(); else data.append("&").append(URLEncoder.encode("members["+i+"][userid]", "UTF-8")).append("=").append(URLEncoder.encode(""+users[i].getUserId(), "UTF-8"));
            if (data.length()>=BUFFER_MAX) {
                processed=true;
                data.trimToSize();
                MoodleRestWebService.call(data.toString());
                data=new StringBuilder();
                data.append(URLEncoder.encode("wstoken", "UTF-8")).append("=").append(URLEncoder.encode(MoodleRestWebService.getToken(), "UTF-8"));
                data.append("&").append(URLEncoder.encode("wsfunction", "UTF-8")).append("=").append(URLEncoder.encode("moodle_group_add_groupmembers", "UTF-8"));
            } else
                processed=false;
        }
        if (!processed) {
            data.trimToSize();
            MoodleRestWebService.call(data.toString());
        }
    }

    /**
     * Method to remove a users membership of a Moodle group
     * @param user MoodleGroupUser
     * @throws MoodleRestGroupException
     * @throws UnsupportedEncodingException
     */
    public static void deleteMemberOfGroup(MoodleGroupUser user) throws MoodleRestGroupException, UnsupportedEncodingException {
        MoodleGroupUser[] users=new MoodleGroupUser[1];
        users[0]=user;
        deleteMembersOfGroups(users);
    }

    /**
     * Method to remove a number of users memberships from Moodle groups.
     * @param users MoodleGroupUser[]
     * @throws MoodleRestGroupException
     * @throws UnsupportedEncodingException
     */
    public static void deleteMembersOfGroups(MoodleGroupUser[] users) throws MoodleRestGroupException, UnsupportedEncodingException {
        Hashtable hash=new Hashtable();
        boolean processed=false;
        StringBuilder data=new StringBuilder();
        if (MoodleRestWebService.getAuth()==null)
            throw new MoodleRestGroupException();
        else
            data.append(MoodleRestWebService.getAuth());
        data.append("&").append(URLEncoder.encode("wsfunction", "UTF-8")).append("=").append(URLEncoder.encode("moodle_group_delete_groupmembers", "UTF-8"));
        for (int i=0;i<users.length;i++) {
            if (users[i]==null) throw new MoodleRestGroupException();
            if (users[i].getGroupId()<1) throw new MoodleRestGroupException(); else data.append("&").append(URLEncoder.encode("members["+i+"][groupid]", "UTF-8")).append("=").append(URLEncoder.encode(""+users[i].getGroupId(), "UTF-8"));
            if (users[i].getUserId()<1) throw new MoodleRestGroupException(); else data.append("&").append(URLEncoder.encode("members["+i+"][userid]", "UTF-8")).append("=").append(URLEncoder.encode(""+users[i].getUserId(), "UTF-8"));
            if (data.length()>=BUFFER_MAX) {
                processed=true;
                data.trimToSize();
                MoodleRestWebService.call(data.toString());
                data=new StringBuilder();
                data.append(URLEncoder.encode("wstoken", "UTF-8")).append("=").append(URLEncoder.encode(MoodleRestWebService.getToken(), "UTF-8"));
                data.append("&").append(URLEncoder.encode("wsfunction", "UTF-8")).append("=").append(URLEncoder.encode("moodle_group_delete_groupmembers", "UTF-8"));
            } else
                processed=false;
        }
        if (!processed) {
            data.trimToSize();
            MoodleRestWebService.call(data.toString());
        }
    }
}
